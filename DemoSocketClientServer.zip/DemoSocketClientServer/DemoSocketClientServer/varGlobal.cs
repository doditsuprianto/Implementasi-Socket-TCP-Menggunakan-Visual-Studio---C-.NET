﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoSocketClientServer
{
    class varGlobal
    {
        public static string alamatIPServer;        
        public static int port;
        public static string terimapesandariserver;
        public static string terimapesandiserver;
    }
}
